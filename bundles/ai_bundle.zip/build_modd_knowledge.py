import os
from langchain.document_loaders import DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma

# 1. Load all Markdown docs
loader = DirectoryLoader("docs/", glob="**/*.md")
docs = loader.load()

# 2. Split into chunks
splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
chunks = splitter.split_documents(docs)

# 3. Embed & Persist to Chroma
emb = OpenAIEmbeddings()
vectordb = Chroma.from_documents(
    chunks,
    embedding=emb,
    persist_directory="mod_vectordb"
)
vectordb.persist()

print("✅ Ingestion complete. Vector store at ./mod_vectordb")
