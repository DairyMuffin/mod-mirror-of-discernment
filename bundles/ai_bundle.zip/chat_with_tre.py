import os
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain.chains import RetrievalQA

# 1. Load the vector store
vectordb = Chroma(persist_directory="mod_vectordb", embedding_function=OpenAIEmbeddings())
retriever = vectordb.as_retriever(search_kwargs={"k": 5})
chain = RetrievalQA.from_chain_type(
    llm=ChatOpenAI(model="gpt-4o-mini", temperature=0.2),
    chain_type="stuff",
    retriever=retriever,
    return_source_documents=True
)
fallback_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7)

SYSTEM_PROMPT = (
    "You are Tre, the AI assistant for Mirror of Discernment (MoD). "
    "You primarily answer from the MoD docs. "
    "If the user asks something outside the scope of the docs, respond conversationally."
)

def chat_with_tre():
    print("🤖 Tre: Hello! Ask me anything about MoD (type 'exit' to quit).")
    while True:
        q = input("\nYou: ")
        if q.lower() in ("exit", "quit"):
            break

        # Prepend context for retrieval
        full_query = SYSTEM_PROMPT + "\n\nUser asks: " + q
        result = chain({"query": full_query})
        answer = result["result"].strip()
        sources = result["source_documents"]

        # If chain found no relevant doc, do a normal chat fallback
        if not sources or answer.lower().startswith("i don't know"):
            fallback = fallback_llm.chat([{"role":"system","content":SYSTEM_PROMPT},
                                          {"role":"user","content":q}])
            answer = fallback.choices[0].message.content

            print(f"\n🤖 Tre (chat): {answer}")
        else:
            print(f"\n🤖 Tre: {answer}")
            print("\n📚 Sources:")
            for doc in sources:
                print(" -", doc.metadata["source"])

if __name__ == "__main__":
    chat_with_tre()
import os
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain.chains import RetrievalQA

# 1. Load the vector store
vectordb = Chroma(
    persist_directory="mod_vectordb",
    embedding_function=OpenAIEmbeddings()
)

# 2. Build a retriever
retriever = vectordb.as_retriever(search_kwargs={"k": 5})

# 3. Create the RetrievalQA chain
chain = RetrievalQA.from_chain_type(
    llm=ChatOpenAI(model="gpt-4o-mini", temperature=0.2),
    chain_type="stuff",
    retriever=retriever,
    return_source_documents=True
)

# System prompt to prepend
SYSTEM_PROMPT = (
    "You are Tre, the AI assistant for Mirror of Discernment (MoD). "
    "You have full access to the MoD documentation corpus—including requirements, architecture, API specs, security reviews, deployment guides, and UNFURL theory. "
    "Answer clearly and concisely, and cite file paths when relevant."
)

def chat_with_tre():
    print("🤖 Tre: Hello! Ask me anything about MoD (type 'exit' to quit).")
    while True:
        q = input("\nYou: ")
        if q.lower() in ("exit", "quit"):
            break

        # Include the system prompt in each query
        full_query = SYSTEM_PROMPT + "\n\nUser asks: " + q
        result = chain({"query": full_query})
        
        print("\n🤖 Tre:", result["result"])
        print("\n📚 Sources:")
        for doc in result["source_documents"]:
            print(" -", doc.metadata["source"])

if __name__ == "__main__":
    chat_with_tre()

