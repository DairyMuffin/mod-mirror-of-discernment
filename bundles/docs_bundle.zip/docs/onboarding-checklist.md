# Onboarding Checklist — Mirror of Discernment (MoD)

Welcome new team member! Follow these steps to get productive quickly.

## Day 1
- [ ] Read **Vision & Objectives** (