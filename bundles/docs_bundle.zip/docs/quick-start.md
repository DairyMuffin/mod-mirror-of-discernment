# Quick Start — Mirror of Discernment (MoD)

Welcome! This guide will get you up and running with MoD in just a few commands.

## Prerequisites

- Git  
- Python 3.8+  
- Node.js 16+ (for prototype demo)  

## 1. Clone the repo

```bash
git clone https://github.com/DairyMuffin/mod-mirror-of-discernment.git
cd mod-mirror-of-discernment

